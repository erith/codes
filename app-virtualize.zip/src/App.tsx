import logo from "./logo.svg";
import "./App.css";
import { Map, user } from "./Map";

const itemCount = 3000;
const users = new Array<user>();
for (let i = 0; i < itemCount; i++) {
  users.push({ seq: i, name: `User${i}`, selected: false });
}

function App() {
  return (
    <div className="App">
      <Map items={users}></Map>
    </div>
  );
}

export default App;
