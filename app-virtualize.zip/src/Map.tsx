import { CSSProperties, useEffect, useMemo, useState } from "react";
import {
  FixedSizeGrid,
  FixedSizeGridProps,
  GridChildComponentProps,
} from "react-window";
import AutoSizer from "react-virtualized-auto-sizer";

export type user = {
  seq: number;
  name: string;
  selected: boolean;
};

const cellItem = ({
  columnIndex,
  data,
  rowIndex,
  style,
}: GridChildComponentProps) => {
  return (
    <div style={style}>
      {columnIndex}, {rowIndex} 11
    </div>
  );
};

type MapProps = {
  items?: user[];
};

const getText = (text: string) => {
  console.log("글자가 변동되었습니다.");
  return text;
};

type RowProps = {
  text: string;
  style: CSSProperties;
  items?: user[];
  index: number;
  border: string;
  borderColor: string;
  columnIndex: number;
  rowIndex: number;
};

const MyRow = ({
  text,
  style,
  items,
  index,
  border,
  borderColor,
  columnIndex,
  rowIndex,
}: RowProps) => {
  const showText = useMemo(() => getText(text), [text]);
  const [color, setColor] = useState(borderColor);
  useEffect(() => {}, []);
  return (
    <div
      style={style}
      onClick={(e) => {
        if (items != null) {
          items[index].selected = !items[index].selected;
          const myColor =
            index == 30 ? "blue" : items[index].selected ? "red" : "black";
          setColor(myColor);
        }
      }}
    >
      <div
        style={{
          border: border,
          height: style.height,
          backgroundColor: color,
        }}
      >
        {index} {color}
        {columnIndex}, {rowIndex} {showText}
      </div>
    </div>
  );
};

export const Map = (props: MapProps) => {
  const cols = 20;

  const rows = Math.ceil((props.items?.length ?? 1) / cols);
  console.log("rows=>" + rows);

  return (
    <AutoSizer>
      {({ width, height }) => {
        console.log("test" + width);
        return (
          <FixedSizeGrid
            columnCount={cols}
            rowCount={rows}
            columnWidth={100}
            rowHeight={100}
            width={width}
            height={height}
            itemData={props.items}
          >
            {({
              columnIndex,
              data,
              rowIndex,
              style,
            }: GridChildComponentProps) => {
              const index = cols * rowIndex + columnIndex;
              let selected = false;
              if (props.items != null && props.items.length > index) {
                selected = props.items[index].selected;
              }

              const borderColor = selected ? "red" : "black";
              const border = `1px solid ${borderColor}`;
              const text = borderColor;
              {
                return MyRow({
                  text: text,
                  style: style,
                  items: props.items,
                  index,
                  border,
                  borderColor,
                  columnIndex,
                  rowIndex,
                } as RowProps);
              }
              {
                /**
              return (

                
                <div
                  style={style}
                  onClick={(e) => {
                    if (props.items != null) {
                      props.items[index].selected =
                        !props.items[index].selected;
                    }
                  }}
                >
                  <div
                    style={{
                      border: border,
                      height: style.height,
                      backgroundColor: borderColor,
                    }}
                  >
                    {columnIndex}, {rowIndex}
                  </div>
            </div>

            );
                         */
              }
            }}
          </FixedSizeGrid>
        );
      }}
    </AutoSizer>
  );
};
