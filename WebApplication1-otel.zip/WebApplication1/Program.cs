using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using Serilog;
using Serilog.Events;
using SerilogTracing.Sinks.OpenTelemetry;

namespace WebApplication1;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.

        builder.Services.AddControllers();
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        // OpenTelemetry Tracing ���� (���ϴ� ��� ���� ����)
        builder.Services.AddOpenTelemetry().WithTracing(traceBuilder =>
        {
            traceBuilder
                .SetResourceBuilder(ResourceBuilder.CreateDefault().AddService("MyServiceName"))
                .SetSampler<AlwaysOnSampler>() //�׻���
                .AddAspNetCoreInstrumentation()
                .AddHttpClientInstrumentation()
                .AddConsoleExporter()
                .AddOtlpExporter(x =>
                {
                    x.Endpoint = new Uri("http://192.168.0.130:4317");
                    x.Protocol = OpenTelemetry.Exporter.OtlpExportProtocol.Grpc;
                })
                ;
        });

        // Serilog �ΰ� ����
        Log.Logger = new LoggerConfiguration()
            .WriteTo.Console() // �ܼ� ���
            .WriteTo.OpenTelemetry(options =>
            {
                options.Endpoint = "http://192.168.0.130:4318";
                options.Protocol = Serilog.Sinks.OpenTelemetry.OtlpProtocol.HttpProtobuf;
                options.IncludedData = (Serilog.Sinks.OpenTelemetry.IncludedData)(IncludedData.MessageTemplateTextAttribute |
                                      IncludedData.TraceIdField | IncludedData.SpanIdField);
            })
            .CreateLogger();

        builder.Services.AddSerilog(); // <-- Add this line

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseAuthorization();
        app.UseSerilogRequestLogging(options =>
        {
            // Customize the message template
            options.MessageTemplate = "Handled {RequestPath}";

            // Emit debug-level events instead of the defaults
            options.GetLevel = (httpContext, elapsed, ex) => LogEventLevel.Debug;

            // Attach additional properties to the request completion event
            options.EnrichDiagnosticContext = (diagnosticContext, httpContext) =>
            {
                diagnosticContext.Set("RequestHost", httpContext.Request.Host.Value);
                diagnosticContext.Set("RequestScheme", httpContext.Request.Scheme);
            };
        });

        app.MapControllers();

        app.Run();
    }
}
