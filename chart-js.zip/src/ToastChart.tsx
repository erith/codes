import faker from "@faker-js/faker";
import "@toast-ui/chart/dist/toastui-chart.min.css";
import { BarChart, LineChart, ScatterChart } from "@toast-ui/react-chart";
import { ScatterChartOptions } from "@toast-ui/chart/types";
import { useSearchParams } from "react-router-dom";

const getDummy = (count: number) => {
  return {
    data: {
      series: [
        {
          name: "male",
          data: Array.from({ length: count / 2 }, () => ({
            x: faker.datatype.number({ min: 145, max: 2200 }),
            y: faker.datatype.number({ min: 40, max: 2120 }),
          })),
        },
        {
          name: "female",
          data: Array.from({ length: count / 2 }, () => ({
            x: faker.datatype.number({ min: 145, max: 2200 }),
            y: faker.datatype.number({ min: 40, max: 2120 }),
          })),
        },
      ],
    },

    options: {
      chart: {
        width: 1400,
        height: 600,
        title: "Height vs Weight",
        animation: false,
      },
      usageStatistics: false,
      plot: {
        visible: false,
      },
      yAxis: {
        title: "Weight (kg)",
      },
      xAxis: {
        title: "Height (cm)",
      },

      tooltip: {
        template: function (category: any, items: any) {
          return (
            '<div style="background-color:#000;color:#000">' +
            `${items.body}` +
            "</div>"
          );
        },
      },
    } as ScatterChartOptions,
  } as any;
};

const options = {
  chart: {
    width: 1160,
    height: 650,
    title: "Monthly Revenue",
  },
  yAxis: {
    title: "Month",
  },
  xAxis: {
    title: "Amount",
  },
};

export const ToastChart = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const cnt = parseInt(searchParams.get("cnt") ?? "3000");
  const basicChartDummy = getDummy(cnt);
  return (
    <>
      <ScatterChart
        data={basicChartDummy.data}
        options={basicChartDummy.options}
      ></ScatterChart>
    </>
  );
};
