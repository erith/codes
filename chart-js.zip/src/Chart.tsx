import { Doughnut } from "react-chartjs-2";
import faker from "@faker-js/faker";
//import { BrowserRouter, Routes, Route } from 'react-router-dom';

import {
  Chart as ChartJS,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";
import { Scatter } from "react-chartjs-2";
import { useSearchParams } from "react-router-dom";

ChartJS.register(LinearScale, PointElement, LineElement, Tooltip, Legend);

export const options = {
  scales: {
    y: {
      beginAtZero: true,
    },
  },
};

const getDummy = (count: number) => {
  return {
    datasets: [
      {
        label: "A dataset",
        data: Array.from({ length: count }, () => ({
          x: faker.datatype.number({ min: -15000, max: 15000 }),
          y: faker.datatype.number({ min: -15000, max: 15000 }),
        })),
        backgroundColor: "rgba(255, 99, 132, 1)",
      },
    ],
  };
};

export const Chart = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const cnt = parseInt(searchParams.get("cnt") ?? "3000");
  const data = getDummy(cnt);
  return <Scatter options={options} data={data} />;
};
