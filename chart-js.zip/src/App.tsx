import { useState } from "react";
import logo from "./logo.svg";
import "./App.css";

import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Home } from "./Home";
import { Chart } from "./Chart";
import { ToastChart } from "./ToastChart";

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/chart" element={<Chart />} />
          <Route path="/toast" element={<ToastChart />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
