import { useState } from 'react'
import logo from './logo.svg'
import './App.css'
import { Doughnut } from 'react-chartjs-2';
import faker from "@faker-js/faker"

import {
  Chart as ChartJS,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from 'chart.js';
import { Scatter } from 'react-chartjs-2';

ChartJS.register(LinearScale, PointElement, LineElement, Tooltip, Legend);

export const options = {
  scales: {
    y: {
      beginAtZero: true,
    },
  },
};

export const data = {
  datasets: [
    {
      label: 'A dataset',
      data: Array.from({ length: 30000 }, () => ({
        x: faker.datatype.number({ min: -15000, max: 15000 }),
        y: faker.datatype.number({ min: -15000, max: 15000 }),
      })),
      backgroundColor: 'rgba(255, 99, 132, 1)',
    },
  ],
};

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <Scatter options={options} data={data} />;

    </div>
  )
}

export default App
